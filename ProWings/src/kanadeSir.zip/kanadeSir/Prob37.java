package kanadeSir;

public class Prob37 {
public static void main(String[] args) {
	int a=1;
	for(int i=10;i>=1;i--)
		a=a*i;
	System.out.println(a);
}
}
