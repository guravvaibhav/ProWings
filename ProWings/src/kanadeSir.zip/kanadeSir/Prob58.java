// 58. Print 1 to 10 numbers on Screen But if value becomes 7 Loop must be Terminate.
package kanadeSir;

public class Prob58 {
public static void main(String[] args) {
	for(int i=1;i<=10;i++) {
		System.out.println(i);
		if(i==7)
			break;
	}
}
}
