package kanadeSir;

public class Prob33 {
	public static void main(String[] args) {
		for(int i=57;i<=63;i++)
			System.out.println(i);
	}

}
