package kanadeSir;
import java.util.Scanner;
public class Prob14 {

	public static void main(String[] args) {
		Scanner sc=new Scanner (System.in);
		System.out.println("enter any value");
		int a=sc.nextInt();
		int m=a%10;
		System.out.println("module is "+m);

	}

}
