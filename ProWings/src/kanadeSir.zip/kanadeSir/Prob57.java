package kanadeSir;

import java.util.Scanner;

public class Prob57 {
public static void main(String[] args) {
	Scanner sc=new Scanner (System.in);
	System.out.println("enter 3 num");
	int num1=sc.nextInt();
	int num2=sc.nextInt();
	int num3=sc.nextInt();
	
	
	for(int i=num1;i<=num1;i++) {
		for(int j=num2=1;j<=num2;j++) {
			for(int k=num3;k<=num3;k++) {
				System.out.println(i+""+j+""+k);
			}
		}
	}
}
}
