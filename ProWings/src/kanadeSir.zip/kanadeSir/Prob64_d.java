//	d. Store only 3 values that is 10, 20, 30 into an array Take input value
//     Insert at 0th Position Also move remaining values to R.H.S.
package kanadeSir;

import java.util.Scanner;

public class Prob64_d {
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int i;
		int a[]= {0,0,0,0,0};
		for(i=0;i<=2;i++) {
			
			
			
		}
		

	}
}
