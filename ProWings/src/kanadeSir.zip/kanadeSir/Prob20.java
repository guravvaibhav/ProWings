package kanadeSir;
import java.util.Scanner;
public class Prob20 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter any value");
		int a=sc.nextInt();
		if(a%2!=0)
			System.out.println(a+" is odd number");
		else
			System.out.println(a+" is  even number");
				

	}

}
