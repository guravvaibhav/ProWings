package kanadeSir;

public class Prob39 {

	public static void main(String[] args) {
		int a=1;
		for(int i=5;i>=1;i--)
			a=a*i;
		System.out.println("factorial of a is ; "+a);

	}

}
