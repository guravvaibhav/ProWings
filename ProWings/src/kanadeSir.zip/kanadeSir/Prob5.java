package kanadeSir;
import java.util.Scanner;
public class Prob5 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter radious of the circle");
		int r=sc.nextInt();
		double a=3.14*r*r;
		System.out.println("area of the cirecle is "+a);
		double c=2*3.14*r;
		System.out.println("circumference of the cirecle is "+c);
	}
	
	
			

}
