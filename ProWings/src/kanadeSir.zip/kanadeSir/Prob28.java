package kanadeSir;

public class Prob28 {

	public static void main(String[] args) {
		 System.out.println("even numbers are :-\n");
		 for(int i=0;i<=100;i++) {
			 if(i%2==0)
				 System.out.println(+i);
		 }
			 

	}

}
