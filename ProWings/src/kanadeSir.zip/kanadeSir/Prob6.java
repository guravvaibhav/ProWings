package kanadeSir;
import java.util.Scanner;
public class Prob6 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter two sides of rectangle");
		int s1=sc.nextInt();
		int s2=sc.nextInt();
		int a=s1*s2;
		System.out.println("area of rectangle is "+a);
	}

}
