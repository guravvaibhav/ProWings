package kanadeSir;

public class Prob27 {

	public static void main(String[] args) {
		System.out.println("odd numbers are :-\n");
		for(int i=1;i<=99;i++) {
			if(i%2!=0)
				System.out.println(+i);
			
		}

	}

}
